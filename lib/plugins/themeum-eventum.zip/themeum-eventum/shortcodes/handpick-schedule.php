<?php
if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly


//shortocde
add_shortcode( 'handpick_schedule', function($atts, $content = null){
  	extract(
        shortcode_atts(array(
          'color'			=> '',
          'title_color'		=> '',
          'time_color'		=> '',
          'schedule_cat'	=> 'themeumall',
          'column'			=> '3',
          'class'			=> '',
          'count'			=> '',
          'order_by'		=> 'ASC',
            'style'         => 1
    	), $atts)
    );

  	global $post;

    if($count == ''){
        $count = '-1';
    }
    
  	if( $schedule_cat == 'themeumall' ){
        $args = array(
            'post_type' => 'schedule',
            'order' => esc_attr($order_by),
            'posts_per_page' => esc_attr($count)
        );
  	}else{
  		$args = array(
	        'post_type' => 'schedule',
            'order' => esc_attr($order_by),
            'posts_per_page' => esc_attr($count),
	        'tax_query' => array(
                array(
                    'taxonomy' => 'schedule_cat',
                    'field'    => 'slug',
                    'terms'    => esc_attr($schedule_cat),
                ),
            ),
	    );
  	}

  	$schedule = new WP_Query($args);
    
    
    $output = '';

        if($color != ''){
            $color = 'color: '.$color;
        }
        if($time_color != ''){
            $time_color = 'color: '.$time_color;
        }
        if($title_color != ''){
            $title_color = 'color: '.$title_color;
            $output .= '
            <script>
                jQuery("head").append("<style>.eventum-handpick-schedule .schedule-day span{'.$title_color.'}</style>"); 
            </script>';
        }
    
    if ( $schedule->have_posts() ){
        $output .= '<div class="row schedule-masonry">';
        while($schedule->have_posts()) {
            $schedule->the_post();
	        $date_of_event = get_post_meta(get_the_ID(),'themeum_date_of_event',true);
            $event_info_group = get_post_meta(get_the_ID(),'event_info_group',true);
            
                $output .= '<div class="col-sm-6 col-md-'.$column.' eventum-handpick-column '.$class.'">';
                    $output .= '<div class="eventum-handpick-schedule" style="'.$color.'">';
                        $output .= '<div class="schedule-day">'.$date_of_event.'</div>';
                        foreach( $event_info_group as $value ){
                            $output .= '<div class="event-schedule style-'.$style.'">';
                                if($style == 2){
                                    $output .= '<div class="event-info time-up" style="'.$time_color.'">';
                                        $output .= '<span class="time">'.esc_attr( $value["themeum__time"] ).'</span>';
                                        //$output .= '<span class="venue">'.esc_attr( $value["themeum_venue"] ).'</span>';
                                    $output .= '</div>';
                                }
                                //session_link
                                if(isset( $value["themeum_session_link"] )){ 
                                    if( $value["themeum_session_link"] != '' ){
                                        $output .= '<a href="'.esc_url($value["themeum_session_link"]).'">';
                                    }
                                }
                                //session
                                $output .= '<h4 style="'.$title_color.'">'.esc_attr($value["themeum_session"]).'</h4>';
                                //session_link
                                if(isset( $value["themeum_session_link"] )){ 
                                    if( $value["themeum_session_link"] != '' ){
                                        $output .= '</a>';
                                    }
                                }
                                //speaker
                                if(!empty($value["themeum__speaker"])){
                                    if(is_array($value["themeum__speaker"])){
                                        $output .= '<div class="speaker">Speaker: <span>';
                                            $xi = 1;
                                            foreach($value["themeum__speaker"] as $osm){
                                              if($xi>1){ $output .= ' , '; }
                                                    $output .= '<a class="speaker" href="'.get_permalink( esc_attr( $osm ) ).'">'.get_the_title( esc_attr( $osm ) ).'</a> ';
                                              $xi++;
                                            }
                                        $output .=  '</span></div>';
                                    }
                                }
                                if($style == 1){
                                    $output .= '<div class="event-info">';
                                        $output .= '<span class="time">'.esc_attr( $value["themeum__time"] ).'</span>';
                                        $output .= '<span class="venue">'.esc_attr( $value["themeum_venue"] ).'</span>';
                                    $output .= '</div>';
                                }
                            $output .= '</div>';
                        }
                    $output .= '</div>';
                $output .= '</div>';
            
        }
        wp_reset_query();
        $output .= '</div>';
    } 
    
	return $output;
     
});



//Visual Composer addons register
if (class_exists('WPBakeryVisualComposerAbstract')) {
  vc_map(array(
    "name" => esc_html__("Handpick Schedule", "themeum-eventum"),
    "base" => "handpick_schedule",
    'icon' => 'icon-thm-speaker-listing',
    "class" => "",
    "description" => esc_html__("Handpick Schedule", "themeum-eventum"),
    "category" => esc_html__('Themeum', "themeum-eventum"),
    "params" => array(   
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Category Filter", 'themeum-eventum'),
            "param_name" => "schedule_cat",
            "value" => themeum_cat_list('schedule_cat'),
        ),   
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Style", 'themeum-eventum'),
            "param_name" => "style",
            "value" => array('Style 1' => 1, 'Style 2' => 2),
        ), 
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Order By", 'themeum-eventum'),
            "param_name" => "order_by",
            "value" => array('Ascending'=>'ASC','Descending'=>'DESC'),
        ), 
        array(
            "type" => "textfield",
            "heading" => esc_html__("Schedule Count", 'themeum-eventum'),
            "param_name" => "count",
            "value" => "",
        ),          
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Number Of Column", "themeum-eventum"),
            "param_name" => "column",
            "value" => array('column 4'=>'3','column 3'=>'4','column 2'=>'6'),
        ),  
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Title Color", "themeum-eventum"),
            "param_name" => "title_color",
            "value" => "",
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Text Color", "themeum-eventum"),
            "param_name" => "color",
            "value" => "",
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Time Color", "themeum-eventum"),
            "param_name" => "time_color",
            "value" => "",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Custom Class", "themeum-eventum"),
            "param_name" => "class",
            "value" => "",
        ),
    )

    ));
}