<?php

if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly


//shortocde
add_shortcode( 'themeum_handpick_speaker_listing', function($atts, $content = null){
  	extract(shortcode_atts(array(
    	'count_post' 	=>	1,
    	'class' 		=>	'',
        'speakers'      =>  '',
        'content_color' =>  '',
        'name_color' =>  '',
        'designation_color' =>  '',
        'social_color' =>  '',
        'bg_color' =>  '',
    	), $atts));
    
    if($content_color != ''){
        $content_color = 'color: '.$content_color.';';
    }

    if($name_color != ''){
        $name_color = 'color: '.$name_color.';';
    }
    
    if($designation_color != ''){
        $designation_color = 'color: '.$designation_color.';';
    }
    
    if($social_color != ''){
        $social_color = 'color: '.$social_color.';';
    }
    
    if($bg_color != ''){
        $bg_color = 'background-color: '.$bg_color.';';
    }


  	global $post;
  	$args = array();


    $args = array(
      'post_type' => 'speaker',
      'order' => 'DESC',
      'name' => $speakers,
      'posts_per_page' => esc_attr($count_post)
    );

  	

  	$speakers = new WP_Query($args);


  	$output = '<div class="themeum-speaker-listing ' . esc_attr($class) .'">';

  		if ( $speakers->have_posts() ){
            while($speakers->have_posts()) {
                $speakers->the_post();
                $designation = get_post_meta(get_the_ID(),'themeum_designation',true);
                $company = get_post_meta(get_the_ID(),'themeum_company',true);
                $facebook = get_post_meta(get_the_ID(),'themeum_facebook_url',true);
                $soundcloud = get_post_meta(get_the_ID(),'themeum_soundcloud_url',true);
                $twitter = get_post_meta(get_the_ID(),'themeum_twitter_url',true);
                $dribbble = get_post_meta(get_the_ID(),'themeum_dribbble_url',true);
                $flickr = get_post_meta(get_the_ID(),'themeum_flickr_url',true);
                $google = get_post_meta(get_the_ID(),'themeum_google_url',true);
                $pinterest = get_post_meta(get_the_ID(),'themeum_pinterest_url',true);
                $youtube = get_post_meta(get_the_ID(),'themeum_youtube_url',true);
                $linkedin = get_post_meta(get_the_ID(),'themeum_linkedin_url',true);
                $behance = get_post_meta(get_the_ID(),'themeum_behance_url',true);
                $vk = get_post_meta(get_the_ID(),'themeum_vk_url',true);
                $skype = get_post_meta(get_the_ID(),'themeum_skype_url',true);
                $instagram = get_post_meta(get_the_ID(),'themeum_instagram_url',true);

                $output .= '<div class="col-xs-12">';
                    $output .= '<div class="speaker-inner clearfix" style="'.$bg_color.'">';
                        $output .= '<div class="speaker-img">';
                            if (has_post_thumbnail( $post->ID ) ) { 
                                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'medium' );
                                $output .= '<img class="img-responsive" src="'.esc_url( $image[0] ).'" alt="'.get_the_title().'">';
                            }
                        $output .= '</div>';
                        $output .= '<div class="speaker-content" style="'.$content_color.'">';
                            $output .= '<a href="'.get_the_permalink().'" class="h4" style="'.$name_color.'">'.get_the_title().'</a>';
                            $output .= '<div class="h6" style="'.$designation_color.'">'.$designation.'</div>';
                            $output .= the_excerpt_max_charlength('120').'...';

                            $output .= '<div class="social-icons">';
                                $output .= '<ul class="social-links-4" style="'.$social_color.'">';
                                    $count = 1;

                                    if( ( $facebook != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-facebook" href="'.esc_url( $facebook ).'"><i class="fa fa-facebook"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $soundcloud != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr($count).'">';
                                            $output .= '<a target="_blank" class="social-soundcloud" href="'.esc_url( $soundcloud ).'"><i class="fa fa-soundcloud"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $twitter != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-twitter" href="'.esc_url( $twitter ).'"><i class="fa fa-twitter"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $dribbble != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-dribbble" href="'.esc_url( $dribbble ).'"><i class="fa fa-dribbble"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $flickr != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-flickr" href="'.esc_url( $flickr ).'"><i class="fa fa-flickr"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $google != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-google-plus" href="'.esc_url( $google ).'"><i class="fa fa-google-plus"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $pinterest != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-pinterest" href="'.esc_url( $pinterest ).'"><i class="fa fa-pinterest"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $youtube != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-youtube" href="'.esc_url( $youtube ).'"><i class="fa fa-youtube"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $linkedin != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-linkedin" href="'.esc_url( $linkedin ).'"><i class="fa fa-linkedin"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $behance != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-behance" href="'.esc_url( $behance ).'"><i class="fa fa-behance"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $vk != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-vk" href="'.esc_url( $vk ).'"><i class="fa fa-vk"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $skype != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-skype" href="'.esc_url( $skype ).'"><i class="fa fa-skype"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                    if( ( $instagram != '' )&&( $count <= 4 ) ){
                                        $output .= '<li class="social-'.esc_attr( $count ).'">';
                                            $output .= '<a target="_blank" class="social-instagram" href="'.esc_url( $instagram ).'"><i class="fa fa-instagram"></i></a>';
                                        $output .= '</li>';
                                    $count++;
                                    }
                                $output .= '</ul>';
                            $output .= '</div>'; // social icons

                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</div>';
            }
		}
		$output .= '</div>'; //themeum-speaker-listing 	

	return $output;
     
}); 



function themeum_list_speaker(){

	$projects = get_posts( array(
	    'posts_per_page'   => -1,
	    'orderby'          => 'post_date',
	    'order'            => 'DESC',
	    'post_type'        => 'speaker',
	    'post_status'      => 'publish',
	    'suppress_filters' => true 
	) );
	$list_schedules = array();

	foreach ($projects as $post) {
	    $list_schedules[$post->post_name] = $post->post_title;
	}
	$list_schedules = array_flip( $list_schedules );

	return $list_schedules;
}


//Visual Composer addons register
if (class_exists('WPBakeryVisualComposerAbstract')) {
  vc_map(array(
    "name" => esc_html__("Handpick Speaker", "themeum-eventum"),
    "base" => "themeum_handpick_speaker_listing",
    'icon' => 'icon-thm-speaker-listing',
    "class" => "",
    "description" => esc_html__("Handpick Speaker", "themeum-eventum"),
    "category" => esc_html__('Themeum', "themeum-eventum"),
    "params" => array(        
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Select Speaker","themeum-eventum"),
            "param_name" => "speakers",
            "value" => themeum_list_speaker(), 
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Content Color", "themeum-eventum"),
            "param_name" => "content_color",
            "value" => "",
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Name/Title Color", "themeum-eventum"),
            "param_name" => "name_color",
            "value" => "",
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Designation Color", "themeum-eventum"),
            "param_name" => "designation_color",
            "value" => "",
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Social Color", "themeum-eventum"),
            "param_name" => "social_color",
            "value" => "",
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Background Color", "themeum-eventum"),
            "param_name" => "bg_color",
            "value" => "",
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Custom Class", "themeum-eventum"),
            "param_name" => "class",
            "value" => "",
        ),

      )

    ));
}





