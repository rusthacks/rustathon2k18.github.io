<?php
if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly


//shortocde
add_shortcode( 'post_box', function($atts, $content = null){
  	extract(
        shortcode_atts(array(
          'column'			=> '3',
          'height'			=> '360px',
          'class'			=> '',
          'count'			=> '',
          'order_by'		=> 'ASC'
    	), $atts)
    );

  	global $post;

    if($count == ''){
        $count = '-1';
    }
    
    $args = array(
        'post_type' => 'post',
        'order' => esc_attr($order_by),
        'posts_per_page' => esc_attr($count)
    );

  	$q = new WP_Query($args);
    
    
    $output = '';
    
    if ( $q->have_posts() ){
        while($q->have_posts()) {
            $q->the_post();
            $idd = $q->ID;
            if ( has_post_thumbnail() ) {
                $post_bg = wp_get_attachment_url( get_post_thumbnail_id() );
            }
            $output .= '<div class="col-sm-6 col-md-'.$column.' '.$class.' postbox-column">';
                $output .= '<a class="post-inner" style="background-image: url('.$post_bg.'); height: '.$height.'" href="'.get_the_permalink().'">';
                    $output .=  '<div class="inner-cell">';
                        $output .=  '<div class="post_meta">';
                            $output .=  '<span>'.get_the_date().'</span>';
                            $output .=  '<span>'.get_comments_number( $idd ).' Comments</span>';
                        $output .=  '</div>';
                        $output .=  '<h4>'.get_the_title().'</h4>';
                    $output .=  '</div>';
                $output .= '</a>';
            $output .= '</div>';
        }
        wp_reset_query();
    } 
    
	return $output;
     
});



//Visual Composer addons register
if (class_exists('WPBakeryVisualComposerAbstract')) {
  vc_map(array(
    "name" => esc_html__("Post Box", "themeum-eventum"),
    "base" => "post_box",
    "class" => "",
    "description" => esc_html__("Post Box", "themeum-eventum"),
    "category" => esc_html__('Themeum', "themeum-eventum"),
    "params" => array(   
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Order By", 'themeum-eventum'),
            "param_name" => "order_by",
            "value" => array('Ascending'=>'ASC','Descending'=>'DESC'),
        ), 
        array(
            "type" => "textfield",
            "heading" => esc_html__("Post Count", 'themeum-eventum'),
            "param_name" => "count",
            "value" => "",
        ),          
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Number Of Column", "themeum-eventum"),
            "param_name" => "column",
            "value" => array('column 4'=>'3','column 3'=>'4','column 2'=>'6'),
        ), 
        array(
            "type" => "textfield",
            "heading" => esc_html__("Height", "themeum-eventum"),
            "param_name" => "height",
            "value" => "360px",
        ), 
        array(
            "type" => "textfield",
            "heading" => esc_html__("Custom Class", "themeum-eventum"),
            "param_name" => "class",
            "value" => "",
        )
    )

    ));
}